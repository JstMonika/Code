#include <bits/stdc++.h>
using namespace std;
int n,k,v,w,v_sum,w_sum,M;
vector < pair<int,int> > _list;

void run(int x){
    
    if(x >= n or w_sum >= k){
        
        M = max(M,v_sum);
        return;
    
    }
    
    if(w_sum + _list[x].second <= k){
        w_sum += _list[x].second;
        v_sum += _list[x].first;
		
        run(x+1);
        
		w_sum -= _list[x].second;
        v_sum -= _list[x].first;
    }
    
    run(x+1);
    
    
}

int main(){
    
    cin >> n >> k;
    
    for(int i=0;i<n;i++){
        cin >> v >> w;
        _list.emplace_back(v,w);
    }
    
    M = 0;
    for(int i=0;i<n;i++){
        w_sum = 0;
        v_sum = 0;
        run(i);
    }
    cout << M;
}