#include <bits/stdc++.h>
using namespace std;

struct Node
{
	char ch;
	
	Node* left;
	Node* right;
};

Node* prefix()
{
	Node* head = (Node*) malloc(sizeof(Node));
	
	cin >> head->ch;
	
	if (head->ch == '&' or head->ch == '|')
	{
		head->left = prefix();
		head->right = prefix();
	}
	else
	{
		head->left = NULL;
		head->right = NULL;
	}
	
	return head;
}

int ans(Node* head, int i)
{
	if (head->ch == '|')
		return ans(head->left, i) | ans(head->right, i);
	
	if (head->ch == '&')
		return ans(head->left, i) & ans(head->right, i);
	
	return (i>>('D' - head->ch)) & 1;
}

int main()
{
	Node* root = prefix();
	
	for (int i = 0; i < 16; i++)
	{
		printf("%d %d %d %d ", (i>>3) & 1, (i>>2) & 1, (i>>1) & 1, i & 1);
		printf("%d\n", ans(root, i));
	}
}