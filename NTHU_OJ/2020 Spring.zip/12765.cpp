#include <bits/stdc++.h>
using namespace std;

class NUM
{
	public:
		static const int base = 100000000;
		static const int width = 8;
		static const int size = 4000;
		
		NUM();
		NUM(string);
		
		NUM operator+(NUM&);
		NUM& operator=(NUM);
		friend istream& operator>>(istream&, NUM&);
		friend ostream& operator<<(ostream&, NUM);
		
	private:
		int arr[size];
};

NUM::NUM()
{
	memset(arr, 0, sizeof(arr));
}

NUM::NUM(string source)
{
	memset(arr, 0, sizeof(arr));
	
	int w = source.size() / width;
	int first;
	if (source.size() % width)
	{
		first = source.size() % width;
		w++;
	}
	else
		first = width;
	
	int k = 0;
	for (int i = w-1; i >= 0; i--)
	{
		int sum = 0;
		int count = 0;
		
		while (count < (i == w-1 ? first : width))
		{
			sum *= 10;
			sum += source[k++] - '0';
			
			count++;
		}
		
		arr[i] = sum;
	}
}

NUM NUM::operator+(NUM& source)
{
	NUM tmp;
	
	for (int i = 0; i < size; i++)
	{
		tmp.arr[i] += arr[i] + source.arr[i];
		
		if (tmp.arr[i] > base)
		{
			tmp.arr[i] -= base;
			tmp.arr[i+1] += 1;
		}
	}
	
	return tmp;
}

NUM& NUM::operator=(NUM source)
{
	for (int i = 0; i < size; i++)
		arr[i] = source.arr[i];
	
	return *this;
}

istream& operator>>(istream& in, NUM& source)
{
	string str;
	cin >> str;
	
	source = NUM(str);
	
	return in;
}

ostream& operator<<(ostream& out, NUM source)
{
	bool start = false;
	for (int i = source.size - 1; i >= 0; i--)
	{
		if (start)
		{
			cout << setw(8) << setfill('0') << source.arr[i];
		}
		else if (source.arr[i])
		{
			start = true;
			cout << source.arr[i];
		}
	}
	
	return out;
}

NUM sol(int i)
{
	NUM ans("1");
	NUM tmp("2");
	
	for (int m = 2; m <= i; m++)
	{
		ans = ans + tmp;
		
		tmp = tmp + tmp;
	}
	
	return ans;
}

int main()
{
	int c;
	cin >> c;
	
	while (c--)
	{
		int p;
		cin >> p;
		
		cout << sol(p) << endl;
	}
}