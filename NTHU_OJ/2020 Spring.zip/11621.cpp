#include <bits/stdc++.h>
using namespace std;

int main()
{
	// do from each character.
	// do two characters.
	
	string str;
	
	while (cin >> str)
	{
		int ans = 0;
		for (int i = 0; i < str.size(); i++)
		{
			int extend = 1;
			while (i+extend < str.size() and i-extend >= 0)
			{
				if (str[i+extend] == str[i-extend])
				{
					ans++;
					extend++;
				}
				else
					break;
			}
		}
		
		for (int i = 0; i < str.size()-1; i++)
		{
			int extend = 1;
			if (str[i] == str[i+1])
			{
				ans++;
				
				while (i-extend >= 0 and (i+1)+extend < str.size())
				{
					if (str[i-extend] == str[i+1+extend])
					{
						ans++;
						extend++;
					}
					else
						break;
				}
			}
		}
		
		cout << ans << endl;
	}
}