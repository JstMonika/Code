#include <bits/stdc++.h>
using namespace std;


struct Node
{
	int op;	// -1 -> ADD, -2 -> SUB, -3 -> MUL.
	int result;
	
	int size;
	
	Node* left;
	Node* right;
	Node* parent;
};

Node* root;

void free_tree(Node* head)
{
	if (head == NULL)
		return;
	
	free_tree(head->left);
	free_tree(head->right);
	
	free(head);
}

Node* make_tree()
{
	Node* head = (Node*) malloc(sizeof(Node));
	
	char ch;
	
	if (isdigit((ch = cin.get())))
	{
		head->op = ch - '0';
		head->result = ch - '0';
		
		head->size = 1;
		
		head->left = NULL;
		head->right = NULL;
	}
	else
	{
		head->left = make_tree();
		head->left->parent = head;
		head->right = make_tree();
		head->right->parent = head;
		
		switch (ch)
		{
			case '+':
				head->op = -1;
				head->result = (head->left->result + head->right->result) % 10007;
				break;
			case '-':
				head->op = -2;
				head->result = (head->left->result - head->right->result) % 10007;
				break;
			case '*':
				head->op = -3;
				head->result = (head->left->result * head->right->result) % 10007;
		}
		
		head->size = head->left->size + head->right->size + 1;
	}
	
	return head;
}

Node* FIND(int num)
{
	Node* head = root;
	int idx = 1;
	
	while (idx != num)
	{
		if (idx + head->left->size >= num)
		{
			idx++;
			head = head->left;
		}
		else
		{
			idx += head->left->size + 1;
			head = head->right;
		}
	}
	
	return head;
}

int VAL(int num)
{
	Node* goal = FIND(num);
	
	return goal->result;
}

void DEL(int s, int e)
{
	Node* start = FIND(s);
	
	if (start == root)
	{
		root = FIND(e+1);
		root->parent = NULL;
	}
	else
	{
		Node* end = FIND(e+1);
		Node* s_parent = start->parent;
		
		if (s_parent->left == start)
			s_parent->left = end;
		else
			s_parent->right = end;
		
		if (end->parent->left == end)
			end->parent->left = NULL;
		else
			end->parent->right = NULL;
		
		end->parent = s_parent;
		
		free_tree(start);
		
		while (s_parent != NULL)
		{
			s_parent->size = s_parent->left->size + s_parent->right->size + 1;
			
			switch (s_parent->op)
			{
				case -1:
					s_parent->result = (s_parent->left->result + s_parent->right->result) % 10007;
					break;
				case -2:
					s_parent->result = (s_parent->left->result - s_parent->right->result) % 10007;
					break;
				case -3:
					s_parent->result = (s_parent->left->result * s_parent->right->result) % 10007;
					break;
			}
			
			s_parent = s_parent->parent;
		}
	}
}

int main()
{
	int c;
	cin >> c;
	cin.get();
	
	root = make_tree();
	root->parent = NULL;
	
	for (int i = 0; i < c; i++)
	{
		char req;
		cin >> req;
		
		if (req == 'Q')
		{
			int num;
			cin >> num;
			
			cout << (VAL(num) + 10007) % 10007 << endl;
		}
		else
		{
			int s, e;
			cin >> s >> e;
			
			DEL(s, e);
		}
	}
}
