#include <bits/stdc++.h>
using namespace std;

vector< vector<int> > graph(101);
vector<bool> pass(101);
double ans = 0;

void go(int i, int value)
{
	pass[i] = true;
	
	for (int k = 1; k < 101; k++)
		if (graph[i][k] and !pass[k])
		{
			graph[i][k] = (graph[i][k] < value+1) ? graph[i][k] : value+1;
			go(k, value+1);
		}
	
	pass[i] = false;
}

int main()
{
	int a, b;
	int c = 1;
	
	while (true)
	{
		bool content = false;
		
		for (int i = 1; i < 101; i++)
		{
			graph[i].clear();
			graph[i].resize(101);
			pass[i] = false;
		}
		
		set<int> exist;
		int path = 0;
		
		while (cin >> a >> b)
		{
			if (a == 0 and b == 0)
				break;
			
			graph[a][b] = 100;
			exist.insert(a);
			exist.insert(b);
			path++;
			
			content = true;
		}
		
		if (content)
		{
			
			for (int i = 1; i < 101; i++)
				go(i, 0);
			for (int i = 1; i < 101; i++)
				for (int k = 1; k < 101; k++)
					ans += graph[i][k];
			
			cout << ans << ' ' << path << endl;
			
			cout << "Case " << c++ << ": average length between pages = " 
				 << fixed << setprecision(3) << ans/path << " clicks" << endl;
			// print the result.
		}
		else
			break;
	}
}