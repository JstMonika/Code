#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main()
{
	char model[20];
	scanf("%s", model);
	for (int i = 0; i < strlen(model); i++)
		model[i] = tolower(model[i]);
	
	
	char str[510];
	int count = 0;
	while (fgets(str, 510, stdin) != NULL)
	{
		char* tmp = strtok(str, " -/:()[],.\n");
		
		while (tmp != NULL)
		{
			for (int i = 0; i < strlen(tmp); i++)
				tmp[i] = tolower(tmp[i]);
			
			if (strcmp(tmp, model))
				;
			else
				count++;
			
			tmp = strtok(NULL, " -/:()[],.\n");
		}
	}
	
	printf("%d\n", count);
}