#include "function.h"
#include <stdlib.h>

unsigned*** new_3d_array(unsigned n, unsigned m, unsigned k)
{
	unsigned*** arr = (unsigned***) malloc(n * sizeof(unsigned**));
	unsigned** mpart = (unsigned**) malloc(n*m * sizeof(unsigned*));
	unsigned* kpart = (unsigned*) malloc(n*m*k * sizeof(unsigned));
	
	for (int i = 0; i < n; i++)
	{
		arr[i] = &mpart[i*m];
		
		for (int j = 0; j < m; j++)
		{
			mpart[i*m + j] = &kpart[i*m*k + j*m + k];
		}
	}
	
	return arr;
}

void delete_3d_array(unsigned*** arr)
{
	free(**arr);
	free(*arr);
	free(arr);
}