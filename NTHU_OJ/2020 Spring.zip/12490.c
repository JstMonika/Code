#include "function.h"
#include <ctype.h>

int solver(int** ptr, int* sum, char* s)
{
	int current = 0, count = 0;
	int num = 0, store = 0, negative = 0;
	int total = 0;
	
	while (1)
	{
		if (isdigit(*(s+current)))
		{
			store = 1;
			
			num *= 10;
			num += (*(s+current) - '0');
		}
		
		else
		{
			if (store)
			{
				if (negative)
					num *= -1;
				
				*(ptr[count++]) = num;
				total += num;
				
				store = num = negative = 0;
			}
			
			if (*(s+current) == '-')
				negative = 1;
		}
		
		// exit test.
		if (*(s+current) == '\0')
			break;
		
		current++;
	}
	
	*sum = total;
	
	return count;
}