#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

struct Node
{
	int num;
	int depth;
	bool del;
	
	struct Node* left;
	struct Node* right;
	struct Node* parent;
};

int max(int m, int n) { return (m > n ? m : n); }

void print(struct Node* head)
{
	if (head == NULL)
		return;
	
	printf("%d", head->num);
	
	print(head->left);
	print(head->right);
}

int find_depth(struct Node* head)
{
	if (head->left == NULL && head->right == NULL)
		return head->depth = 1;
	
	int left = -1, right = -1;
	
	if (head->left != NULL)
		left = find_depth(head->left);
	
	if (head->right != NULL)
		right = find_depth(head->right);
	
	return head->depth = max(left, right) + 1;
}

void check(struct Node* head, int min, int max)
{
	if (head->parent != NULL && head->parent->del == true)
		head->del = true;
	else if (head->num < min || head->num > max)
		head->del = true;
		
	if (head->right != NULL)
		check(head->right, head->num, max);
		
	if (head->left != NULL)
		check(head->left, min, head->num);
}

int main()
{
	int n;
	scanf("%d", &n);
	
	struct Node* ptr = (struct Node*) malloc((n+1) * sizeof(struct Node));
	struct Node* root;
	
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &ptr[i].num);
		
		ptr[i].del = false;
		ptr[i].left = NULL;
		ptr[i].right = NULL;
	}
	
	for (int i = 1; i <= n; i++)
	{
		int tmp;
		scanf("%d", &tmp);
		
		if (tmp)
		{
			if (getchar() == 'R')
			{
				ptr[tmp].right = (ptr+i);
				ptr[i].parent = (ptr+tmp);
			}
			else
			{
				ptr[tmp].left = (ptr+i);
				ptr[i].parent = (ptr+tmp);
			}
		}
		else
		{
			ptr[i].parent = NULL;
			root = (ptr+i);
		}
	}
	
	find_depth(root);
	
	check(root, 0, 2147483647);
	
	for (int i = 1; i <= n; i++)
	{
		printf("%d", (ptr[i].del ? (-1)*ptr[i].depth : ptr[i].num));
		
		if (i == n)
			printf("\n");
		else
			printf(" ");
	}
}