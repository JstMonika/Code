#include <bits/stdc++.h>
using namespace std;

int main()
{
	int m, n, t;
	cin >> m >> n >> t;
	
	vector< vector<char> > _list(m, vector<char>(n));
	cin.get();
	
	for (int i = 0; i < m; i++)
		for (int k = 0; k < n; k++)
		{
			_list[i][k] = cin.get();
			cin.get();
		}
	
	int cas[2][t];
	for (int i = 0; i < t; i++)
	{
		cin >> cas[0][i];
		cin >> cas[1][i];
	}

	
	while (t--)
	{
		int a = cas[0][t] - 1;
		int b = cas[1][t] - 1;
		
		char tmp;
		for (int i = 0; i < m; i++)
		{
			tmp = _list[i][a];
			_list[i][a] = _list[i][b];
			_list[i][b] = tmp;
		}
	}
	for (int i = 0; i < m; i++)
		for (int k = 0; k < n; k++)
			cout << _list[i][k];
		
	cout << endl;
}