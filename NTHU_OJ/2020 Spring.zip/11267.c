#include "function.h"

void execInst(int* Ptr[], char comment, int attacker, int target)
{
	if (comment == 'S')
		*Ptr[attacker] = target;
	
	else
	{
		Ptr[attacker] = Ptr[target];
	}
}