#include <bits/stdc++.h>
using namespace std;

int k, l, r;
int now = -1;

void go(int i)
{
	if (i > k)
		return;
	
	now++;
	
	if (now >= l and now <= r)
		printf("O");
	
	go(i+1);
	
	now++;
	
	if (now >= l and now <= r)
		printf("u");
	
	go(i+1);
	
	now++;
	
	if (now >= l and now <= r)
		printf("Q");
}

int main()
{
	
	while (scanf("%d%d%d", &k, &l, &r) != EOF)
	{
		now = -1;
		go(1);
		
		printf("\n");
	}
}