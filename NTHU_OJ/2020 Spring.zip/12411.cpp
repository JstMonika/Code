#include <bits/stdc++.h>
using namespace std;

const int ten = 100000000;

int main()
{
	long long a, b;
	scanf("%8lld %8lld", &a, &b);
	// printf("%lld %lld", a, b);
	
	long long ans[4] = {0};
	ans[0] += b*b;
	ans[1] += ans[0] / ten;
	ans[1] += 2 * a * b;
	ans[2] += ans[1] / ten;
	ans[2] += a*a;
	ans[3] += ans[2] / ten;
	
	printf("%8lld", ans[3]);
	for (int i = 2; i >= 0; i--)
	{
		ans[i] %= ten;
		printf("%08lld", ans[i]);
	}
	printf("\n");
}