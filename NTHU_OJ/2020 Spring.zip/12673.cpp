#include <bits/stdc++.h>
using namespace std;

int main()
{
	int c;
	cin >> c;
	
	while (c--)
	{
		
		int n, q;
		cin >> n >> q;
		vector<int> _list(q);
		vector<pair<int, int>> line(q);
		
		for (int i = 0; i < q; i++)
		{
			int s, e;
			cin >> s >> e;
			line.emplace_back(s, e);
			_list.push_back(e-s+1);
		}
		
		sort(line.begin(), line.end());
		
		int len = 0, left, right;
		for (int i = 0; i < q; i++)
		{
			if (i)
			{
				if (line[i].first > left)
				{
					left = line[i].first;
					right = line[i].second;
					
					len += line[i].second - line[i].first + 1;
				}
				else
				{
					if (line[i].second > right)
					{
						len += line[i].second - right;
						right = line[i].second;
					}
				}
			}
			else
			{
				len += line[i].second -line[i].first + 1;
				left = line[i].first;
				right = line[i].second;
			}
		}
		w
		
	}
}