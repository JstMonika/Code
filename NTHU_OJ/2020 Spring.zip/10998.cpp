#include "function.h"
using namespace std;

List_stack::List_stack()
{
	head = NULL;
	tail = NULL;
}

List_stack::~List_stack()
{
	if (head == NULL)
		return;
	
	while (head->nextPtr != NULL)
	{
		head = head->nextPtr;
		
		delete head->prevPtr;
	}
	
	delete head;
}

void List_stack::push(const int& d)
{
	if (tail == NULL)
		head = tail = new ListNode(d);
	else
	{
		tail->nextPtr = new ListNode(d);
		tail->nextPtr->prevPtr = tail;
		tail = tail->nextPtr;
	}
}

void List_stack::pop()
{
	if (head == NULL)
		return;
	
	if (tail->prevPtr == NULL)
	{
		delete tail;
		
		head = tail = NULL;
	}
	else
	{
		tail = tail->prevPtr;
		
		delete tail->nextPtr;
		tail->nextPtr = NULL;
	}
}

void List_stack::print()
{
	ListNode* tmp = tail;
	
	if (tmp == NULL)
		return;
	
	while (tmp != head)
	{
		cout << tmp->data << ' ';
		
		tmp = tmp->prevPtr;
	}
	
	cout << tmp->data;
}