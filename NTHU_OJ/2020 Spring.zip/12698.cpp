#include <bits/stdc++.h>
using namespace std;

int n, goal;

vector<bool> answer;
int weight = 1e9;

vector<bool> visit;
vector< pair<int, int> > _list;

void run(int i, int value, int w)
{
	if (i == n)
	{
		if (value < goal)
			return;
		
		if (w < weight)
		{
			weight = w;
			answer = visit;
		}
		
		return;
	}
	visit[i] = true;
	
	run(i+1, value + _list[i].first, w + _list[i].second);
	
	visit[i] = false;
	
	run(i+1, value, w);
}

int main()
{
	cin >> n >> goal;
	
	_list.resize(n);
	visit.resize(n);
	answer.resize(n);
	
	for (auto &i : _list)
		cin >> i.first >> i.second;
	
	run(0, 0, 0);
	
	int output = 0;
	for (int i = 0; i < n; i++)
		if (answer[i])
			output += _list[i].second;
		
	cout << output;
			
}