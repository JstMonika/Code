#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	
	while (cin >> n)
	{
		if (!n)
			break;
		
		map<int, int> count;
		
		while (n--)
		{
			int s, e;
			cin >> s >> e;
			
			count[s]++;
			count[e]++;
		}
		cin >> n;
		
		int ans = 0;
		for_each(count.begin(), count.end(), [&, n](pair<const int, int>& i) { if (i.second == 1 and i.first != n) ans++; });
		
		cout << ans << endl;
	}
}