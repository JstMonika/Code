#include "function.h"

void sortArray(int row, int (*arr)[COLUMN])
{
	for (int m = 0; m < row; m++)
	
	for (int i = 0; i < COLUMN; i++)
		for (int k = i+1; k < COLUMN; k++)
		{
			if (arr[m][i] > arr[m][k])
			{
				int tmp = arr[m][i];
				arr[m][i] = arr[m][k];
				arr[m][k] = tmp;
			}
		}
}