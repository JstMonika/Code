#include <bits/stdc++.h>
using namespace std;

int ans = 0;

vector<int> ex;
vector<int> box;

void put(int point, int n_box, int box_size)
{
	if (point == ex.size())
		ans = n_box;
	
	for (int i = 0; i < n_box; i++)
	{
		if (ex[point] + box[i] <= box_size)
		{
			box[i] += ex[point];
			put(point+1, n_box, box_size);
			box[i] -= ex[point];
		}
	}
}

int main()
{
	int c;
	cin >> c;
	
	while (c--)
	{
		ans = 0;
		
		int n;
		cin >> n;
		
		int sum = 0;
		ex.resize(n);
		for (auto &i : ex)
		{
			cin >> i;
			sum += i;
		}
		
		int n_box = sum;
		for (; n_box >= 1; n_box--)
		{
			if (sum % n_box)
				continue;
			
			box.resize(n_box);
			for (int i = 0; i < n_box; i++)
				box[i] = 0;
			
			put(0, n_box, sum/n_box);
			
			if (ans)
			{
				cout << ans << endl;
				break;
			}
		}
	}
}