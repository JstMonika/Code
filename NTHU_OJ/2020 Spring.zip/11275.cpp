#include <stdio.h>
using namespace std;

void take(int i)
{
	char tmp[20];
	scanf("%s", tmp);
	
	char next = getchar();
	if (next != '\n')
		take(i+1);
	
	if (i)
		printf("%s ", tmp);
	else
		printf("%s\n", tmp);
}

int main()
{
	char tmp;
	while (EOF != scanf("%c", &tmp))
	{
		ungetc(tmp, stdin);
		take(0);
	}
}