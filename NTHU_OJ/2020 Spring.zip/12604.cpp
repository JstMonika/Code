#include <bits/stdc++.h>
using namespace std;

int m, n;	// queen and rook.
int ans;
vector<int> location(10);
vector<bool> put(10);

vector<bool> type(10);

void place(int);
void select(int, int);

int main()
{
	while (cin >> m >> n)
	{
		ans = 0;
		// location first, then queens or rooks.
		
		place(0);	// row.
		
		cout << ans << endl;
	}
}

void select(int qn, int last = -1)
{
	if (qn == m)
	{
		ans++;
		return;
	}
	
	for (int i = last+1; i < m+n; i++)
	{
		bool good = true;
		for (int k = 0; k < m+n; k++)
			if (abs(k-i) == abs(location[k] - location[i]) and k != i)
				good = false;
		
		if (good)
			select(qn+1, i);
	}
}

void place(int r)
{
	if (r == m+n)
	{
		select(0);
		return;
	}
	
	for (int i = 0; i < m+n; i++)
	{
		if (!put[i])
		{
			put[i] = true;
			location[r] = i;
			
			place(r+1);
			
			put[i] = false;
		}
	}
}

