#include <stdio.h>
long long ans = 0;
int k;

void find(int i, int times)
{
	if (k == 0)		// k == 0，答案就是0，直接return
		return;
	if (times == k+1)		// 當times == k+1的時候，就表示我們現在正在跑k+1回合，但是只要跑k回合而已，所以在這裡中斷。
		return;
	
	
	
	if (times == 1)		// 第1回合，只需要把ans+1
	{
		ans += 1;
		find(1, times+1);	// 這回合新增了1個方塊，跑下一個回合(times+1).
	}
	else	// 其他不是第1回合的，把ans加上上回合新增的方塊數量*8
	{
		ans += i * 8;	// 把ans加上上回合新增的方塊數目*8
		find(i*8, times+1);		// 這回合新增了i*8個方塊，跑下一個回合(times+1).
	}
}

int main()
{
	scanf("%d", &k);	// 接收題目給的k值.
	
	find(0, 1);	// 開始計算黑色方塊數量，(0, 0)代表現在有0個方塊，我現在要開始跑第1回合。
	
	printf("%lld\n", ans);
}