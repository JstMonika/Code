#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n, m;
	cin >> n >> m;
	
	vector<int> toy(n);
	for (auto &i : toy)
		cin >> i;
	
	vector<int> bill(m);
	for (auto &i : bill)
		cin >> i;
	
	int curbill = 0, count = 0;
	for (int i = 0; i < n; i++)
	{
		if (bill[curbill] >= toy[i])
		{
			count++;
			curbill++;
			
			if (curbill == m)
				break;
		}
	}
	
	cout << count << endl;
}