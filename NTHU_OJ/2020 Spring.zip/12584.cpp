#include <bits/stdc++.h>
using namespace std;

bool ans;
int n;
int points[15];

bool used[15];
int skill[15];

void put(int fill, int num, int bmax, int bnum)
{
	if (num == bnum)
	{
		// cout << "bmax = " << bmax << endl;
		ans = true;
	}
	
	for (int i = 0; i < n; i++)
	{
		if (!used[i])
		{
			if (fill + points[i] <= bmax)
			{
				used[i] = true;
				fill += points[i];
				
				if (fill == bmax)
					put(0, num+1, bmax, bnum);
				else
					put(fill, num, bmax, bnum);
				
				used[i] = false;
				fill -= points[i];
			}
		}
	}
}

int main()
{
	int c;
	cin >> c;
	
	while (c--)
	{
		ans = false;
		int sum = 0;
		cin >> n;
		
		for (int i = 0; i < n; i++)
		{
			cin >> points[i];
			sum += points[i];
		}
		
		for (int i = n; i >= 1; i--)
		{
			// cout << sum << ' ' << n << '-' << endl;
			
			if (sum % i)
				continue;
			
			memset(used, 0, sizeof(used));
			memset(skill, 0, sizeof(skill));
			
			put(0, 0, sum/i, i);
			
			if (ans)
			{
				cout << i << endl;
				break;
			}
		}
	}
}