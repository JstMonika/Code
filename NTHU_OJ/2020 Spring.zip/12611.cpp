#include <bits/stdc++.h>
using namespace std;

bool leap_func(int y)
{
	if (!(y % 400))
		return true;
	
	if (!(y % 4) and y % 100)
		return true;
	
	return false;
}

int main()
{
	int c;
	cin >> c;
	
	while (c--)
	{
		int year, count = 0;
		cin >> year;
		
		bool leap = leap_func(year);
		
		do
		{
			year++;
			
			if (leap_func(year))
				count += 2;
			else
				count++;
			
		} while (count % 7 or leap != leap_func(year));
		
		cout << year << endl;
	}
}