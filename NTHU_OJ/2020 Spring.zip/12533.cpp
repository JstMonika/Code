#include "function.h"
#include <stdio.h>
#include <math.h>

Point * ones_vec_1(int len)
{
	Point* ptr = (Point*) malloc(len * sizeof(Point));
	
	for (int i = 0; i < len; i++)
		scanf("%d %d", ptr[i]->x, ptr[i]->y);
	
	return ptr;
}

float compute_distance(Point* ptr, int first, int second)
{
	int x_dis = cabs(ptr[first]->x - ptr[second]->x);
	int y_dis = cabs(ptr[first]->y - ptr[second]->y);
	
	return sqrt(x_dis*x_dis + y_dis*ydis);
}