#include <bits/stdc++.h>
using namespace std;

int main()
{
	int c;
	cin >> c;
	
	while (c--)
	{
		int k, t;
		cin >> k >> t;
		
		vector<int> _list(k);
		
		for (int i = 0; i < t; i++)
		{
			int stay, value = 0;
			
			for (int m = 0; m < k; m++)
			{
				if (_list[m] != -1)
					if (m == 0)
						_list[m] = 0;
					else if (_list[m-1] == -1)
						_list[m] = 0;
					else
						_list[m] = _list[m-1] + 1;
			}
			
			for (int m = k-1; m >= 0; m--)
			{
				if (_list[m] != -1)
				{
					if (m == k-1)
						_list[m] = 0;
					else if (_list[m+1] == -1)
						_list[m] = 0;
					else
					{
						_list[m] = min(_list[m], _list[m+1]+1);
					}
					
					if (_list[m] >= value)
					{
						stay = m;
						value = _list[m];
					}
				}
			}
			
			_list[stay] = -1;
			
			/* 
			for (int m = 0; m < k; m++)
				cout << _list[m] << ' ';
			cout << endl;
			 */
			
			if (i == t-1)
				cout << stay+1 << endl;
		}
	}
}