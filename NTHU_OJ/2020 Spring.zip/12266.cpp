#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin >> n;
	
	string pokemon[10] =
	{
	"Waninoko",
	"Milotic",
	"Magikarp",
	"Vaporeon",
	"Sharpedo",
	"Tapu Fini",
	"Empoleon",
	"Lapras",
	"Pikachu",
	"Mega Gyarados"
	};

	while (n--)
	{
		string name, school;
		cin >> name >> school;

		if (name.size() <= 1)
		{
			cout << name << " is looking for a Chinese tutor, too!" << endl;
			continue;
		}

		int which = -1;
		switch(name[0])
		{
			case 'W':
				if (name[1] == 'a')
					which = 0;

				break;
			case 'M':
				if (name[1] == 'i')
					which = 1;
				else if (name[1] == 'a')
					which = 2;
				else if (name[1] == 'e')
					which = 9;

				break;
			case 'V':
				if (name[1] == 'a')
					which = 3;

				break;
			case 'S':
				if (name[1] == 'h')
					which = 4;

				break;
			case 'T':
				if (name.size() >= 4 and name.substr(1, 3) == "apu")
					which = 5;

				break;
			case 'E':
				if (name[1] == 'm')
					which = 6;

				break;
			case 'L':
				if (name[1] == 'a')
					which = 7;

				break;
			case 'P':
				if (name[1] == 'i' or name[1] == 'e')
					which = 8;

				break;
		}

		if (which == -1)
			cout << name << " is looking for a Chinese tutor, too!" << endl;
		else
			cout << name << " the " << school << " " << pokemon[which] << endl;
	}
}
