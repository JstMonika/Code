#include <bits/stdc++.h>
using namespace std;

int size = 80;

char input[100005];
char output[100005];
char tmp[100005];

int main()
{
	gets(input);
	
	int cursor = 0;
	// add to cursor, remove from cursor-1.
	
	for (int i = 0; i < strlen(input); i++)
	{
		if (input[i] == '\\')
		{
			i++;
			
			switch (input[i])
			{
				case 'l':
					if (cursor > 0)
						cursor--;
					
					break;
				case 'r':
					if (output[cursor] != 0)
						cursor++;
				
					break;
				case 'b':
					if (cursor > 0)
					{
						strcpy(tmp, &output[cursor]);
						strcpy(&output[cursor-1], tmp);
						
						cursor--;
					}
					
					break;
				case 'n':
					strcpy(tmp, &output[cursor]);
					strcpy(&output[cursor+1], tmp);
					output[cursor] = '\n';
					
					cursor++;
					
					break;
				case 's':
					int t = 0;
					
					i += 3;
					
					while (!isdigit(input[i]))
					{
						t *= 10;
						t += (input[i] - '0');
						
						i++;
					}
					
					size = t;
					
					while (input[i] != ']') i++;
				
					break;
			}
		}
		else
		{
			strcpy(tmp, &output[cursor]);
			strcpy(&output[cursor+1], tmp);
			output[cursor] = input[i];
			
			cursor++;
		}
	}
	
	int len = 0;
	for (int i = 0; i < strlen(output); i++)
	{
		if (output[i] == '\n')
			len = 0;
		
		if (len == size)
		{
			len = 0;
			
			printf("\n");
		}
		
		printf("%c", output[i]);
		len++;
	}
}