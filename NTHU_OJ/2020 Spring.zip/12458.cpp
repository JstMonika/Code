#include <bits/stdc++.h>
using namespace std;

int n, k;
string str;
bool LR[1000][1000];
bool good = false;

void find(int L, int R, int rem)
{
	if (LR[L][R])
		return;
	if (L >= R)
	{
		if (rem <= k)
			good = true;
		
		return;
	}
	
	LR[L][R] = true;
	
	if (str[L] == str[R])
		find(L+1, R-1, rem);
	else
	{
		find(L+1, R, rem+1);
		find(L, R-1, rem+1);
	}
}


int main()
{
	cin >> n >> k >> str;
	
	find(0, str.size()-1, 0);
	
	if (good)
		cout << "Yes" << endl;
	else
		cout << "No" << endl;
}