#include <bits/stdc++.h>
using namespace std;

struct cat{
    string name;
    int career;
    int age;
};

bool cmp(cat &a,cat &b){
    if(a.career != b.career)return a.career < b.career;
    if(a.age != b.age){
        if(a.career == 5)return a.age < b.age;
        return a.age > b.age;
    }        
    return a.name > b.name;    
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    
    int x,times;
    int n;
	cin >> n;
    while (n--)
	{
		cin >> x >> times;
    vector < cat > _list(x);
    string tmp;
    
    for(int i=0;i<x;i++){
        cin >> _list[i].name >> tmp;
                    
        if(tmp == "elder")_list[i].career = 1;
        
        if(tmp == "nursy")_list[i].career = 2;
        
        if(tmp == "kitty")_list[i].career = 3;
        
        if(tmp == "warrior")_list[i].career = 4;
            
        if(tmp == "apprentice")_list[i].career = 5;
        
        if(tmp == "medicent")_list[i].career = 6;
            
        if(tmp == "deputy")_list[i].career = 7;
            
        if(tmp == "leader")_list[i].career = 8;
        
        cin >> _list[i].age;
    }
    
    sort(_list.begin(),_list.end(),cmp);
	for(int k = 0;k<times and k<x;k++)cout << _list[k].name << endl;
}
}
/*
1. elder
2. nursy
3. kitty
4. warrior
5. apprentice
6. medicent
7. deputy
8. leader
*/