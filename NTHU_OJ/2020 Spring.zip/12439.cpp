#include <bits/stdc++.h>
using namespace std;

int GCD(int a, int b)
{
	if (!b)
		return a;
	
	return GCD(b, a%b);
}

int LCM(int a, int b)
{
	return a * b / GCD(a, b);
}

int POWER(int a, int b)
{
	if (b == 1)
		return a;
	
	return a*POWER(a, b-1);
}

int main()
{
	int A, B, C, D;
	cin >> A >> B >> C >> D;
	
	cout << GCD(LCM(POWER(A, B), C), D) << endl;
	cout << GCD(POWER(LCM(A, B), C), D) << endl;
	cout << LCM(GCD(POWER(A, B), C), D) << endl;
	cout << LCM(POWER(GCD(A, B), C), D) << endl;
	cout << POWER(GCD(LCM(A, B), C), D) << endl;
	cout << POWER(LCM(GCD(A, B), C), D) << endl;
}