#include <bits/stdc++.h>
using namespace std;

using vvi = vector<vector<int>>;
using t = tuple<vvi, int, int>;

auto cmp = [] (const t& a, const t& b)
{
	if (get<1>(a) == get<1>(b))
		return get<2>(a) > get<2>(b);
	
	return get<1>(a) > get<1>(b);
};

priority_queue<t, vector<t>, decltype(cmp)> _list(cmp); 

int cal(vvi p)
{
	int sum = 0;
	
	/*
	for (int i = 0; i < 4; i++)
	{
		for (int k = 0; k < 4; k++)
			cout << p[i][k] << ' ';
		
		cout << endl;
	}
	*/
	
	for (int i = 0; i < 4; i++)
		for (int k = 0; k < 4; k++)
		{
			if (!p[i][k])
				continue;
			
			int delx = (p[i][k]+15) % 16 / 4 - i;
			int dely = (p[i][k]+15) % 16 % 4 - k;
			
			// cout << p[i][k] << abs(delx) << abs(dely) << endl;
			
			sum += abs(delx);
			sum += abs(dely);

			for (int m = i; m < 4; m++)
			{
				if (dely)
					break;
				
				int dy = (p[m][k]+15) % 16 % 4 - k;
				
				if (dy or !p[m][k])
					continue;
				
				if (p[m][k] < p[i][k])
				{
					// cout << p[m][k] << ' ' << p[i][k] << endl;
					sum += 2;
				}
			}
			
			for (int m = k; m < 4; m++)
			{
				if (delx)
					break;
				
				int dx = (p[i][m]+15) % 16 / 4 - i;
				
				if (dx or !p[i][m])
					continue;
				
				if (p[i][m] < p[i][k])
				{
					// cout << p[i][m] << ' ' << p[i][k] << endl;
					sum += 2;
				}
			}
			
		}	
	
	// cout << sum << endl << endl;
	
	return sum;
}

vvi create(const vvi& source, int x, int y, int a, int b)
{
	vvi tmp = source;
	
	int t = tmp[x][y];
	tmp[x][y] = tmp[a][b];
	tmp[a][b] = t;

	return tmp;
}

int main()
{
	vvi p(4, vector<int>(4));
	for (int i = 0; i < 4; i++)
		for (int k = 0; k < 4; k++)
			cin >> p[i][k];
	
	// cout << cal(p) << endl;
	
	set<vvi> exist;
	_list.push(make_tuple(p, cal(p) + 0, 0));

	while (!_list.empty())
	{
		vvi tmp;
		int Astar, depth;

		tie(tmp, Astar, depth) = _list.top();
		
		_list.pop();
		
		if (!(Astar - depth))
		{
			cout << depth << endl;
			break;
		}

		exist.insert(tmp);
		
		int x, y;
		for (int i = 0; i < 16; i++)
			if (tmp[i/4][i%4] == 0)
			{
				x = i/4;
				y = i%4;
				break;
			}
				

		int gx[4] = {0, 1, 0, -1};
		int gy[4] = {1, 0, -1, 0};
		for (int i = 0; i < 4; i++)
		{
			if (x+gx[i] < 0 or x+gx[i] >= 4)
				continue;
			if (y+gy[i] < 0 or y+gy[i] >= 4)
				continue;
			
			vvi swap = create(tmp, x, y, x+gx[i], y+gy[i]);
			
			if (exist.count(swap))
				continue;

			_list.push(make_tuple(swap, cal(swap) + depth+1, depth+1));
			// push move.
		}
	}
	
}
