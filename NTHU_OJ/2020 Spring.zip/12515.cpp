#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n, goal;
	cin >> n >> goal;
	
	vector<int> _list(n);
	vector<int> ans(n);
	for (auto &i : _list)
		cin >> i;
	
	bool first = true;
	for (int i = 1; i < n; i++)
	{
		int k = i-1;
		
		while (!(k < 0 or _list[k] > _list[i]))
		{
			ans[i] += ans[k] + 1;
			
			k -= (ans[k] + 1);
		}
		
		if (ans[i] == goal)
			if (first)
			{
				first = false;
				cout << i+1;
			}
			else
				cout << ' ' << i+1;
	}
	
	if (first)
		cout << "ouo";
	
	cout << endl;
}