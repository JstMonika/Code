#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char expr[260];
int pos;

struct Node
{
	char data;
	
	struct Node* left;
	struct Node* right;
};

Node* EXPR();
Node* FACTOR();
Node* makeNode(char);

Node* EXPR()
{
	Node* right = FACTOR();
	
	if (pos == -1 || expr[pos] == '(')
	{
		pos--;
		return right;
	}
	
	Node* head = makeNode(expr[pos--]);
	
	head->left = EXPR();
	head->right = right;
	
	return head;
}
	Node* FACTOR()
{
	if (expr[pos] == ')')
	{
		pos--;
		return EXPR();
	}
	
	return makeNode(expr[pos--]);
}
	Node* makeNode(char ch)
{
	Node* head = (Node*) malloc(sizeof(Node));
	
	head->data = ch;
	head->left = NULL;
	head->right = NULL;
	
	return head;
}
	void printInfix(Node* head)
{
	if (head->left != NULL)
		printInfix(head->left);
	
	printf("%c", head->data);
	
	if (head->right != NULL)
	{
		if (head->right->data == '|' || head->right->data == '&')
			printf("(");
		
		printInfix(head->right);
		
		if (head->right->data == '|' || head->right->data == '&')
			printf(")");
	}
		free(head);
}
	int main()
{
	scanf("%s", expr);
	pos = strlen(expr) - 1;
	
	printInfix(EXPR());
}