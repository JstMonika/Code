#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin >> n;
	
	int exist[n+1];
	for (int i = 1; i <= n; i++)
		cin >> exist[i];
	
	int s[50];
	int top = -1;
	
	int order[n+1];
	int idx = 1;
	int i = 1;
	while (true)
	{
		while (i <= n)
		{
			s[++top] = i;
			i *= 2;
		}
		
		if (top == -1)
			break;
		
		i = s[top--];
		order[idx++] = i;
		
		i = i * 2 + 1;
	}
	
	/*
	for (int i = 1; i <= n; i++)
		cout << order[i] << ' ';
	cout << endl;
	*/
	
	int c;
	cin >> c;
	
	while (c--)
	{
		string a, b;
		cin >> a >> b;
		
		char aorder[27];
		
		bool stay[n+1];
		memset(stay, 0, sizeof(stay));
		
		int border[a.size()];
		
		int k = 1;
		for (int i = 0; i < a.size(); i++)
		{
			while (!exist[k])
				k++;
			
			aorder[k] = a[i];
			stay[k++] = true;
		}
		
		/*
		for (int i = 0; i < a.size(); i++)
			cout << aorder[i] << ' ';
		cout << endl;
		*/
		
		k = 0;
		for (int i = 1; i <= n; i++)
			if (stay[order[i]])
				border[k++] = order[i];
		
		/*
		for (int i = 0; i < a.size(); i++)
			cout << border[i] << ' ';
		cout << endl;
		*/
		
		bool good = true;
		
		for (int i = 0; i < a.size(); i++)
		{
			// cout << aorder[border[i]] << ' ' << b[i] << endl;
			
			if (b[i] != aorder[border[i]])
				good = false;
		}
		cout << (good ? "Yes\n" : "No\n");
	}
}
