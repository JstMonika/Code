#include <bits/stdc++.h>
using namespace std;

int gx[4] = {-1, 1, 1, -1};
int gy[4] = {1, 1, -1, -1};
// ur, dr, dl, ul.

int main()
{
	int r, c;
	cin >> r >> c;
	
	int nowx, nowy;
	cin >> nowx >> nowy;
	
	int count;
	cin >> count;
	
	int t = 0;
	while (--count)
	{
		bool start = true;
		// cout << '(' << nowx << ',' << nowy << ')' << endl;
		// cout << "t = " << t << endl;
		
		while (true)
		{
			if (nowx+gx[t] > r or nowy+gy[t] > c)
			{
				if (nowx == r)	// d
					t = (t == 1) ? 0 : 3;
				else	// r
					t = (t == 0) ? 3 : 2;
				
				break;
			}
			else if (nowx+gx[t] < 1 or nowy+gy[t] < 1)
			{
				if (nowx == 1) // u
					t = (t == 0) ? 1 : 2;
				else	// l
					t = (t == 2) ? 1 : 0;
				
				break;
			}
			
			nowx += gx[t];
			nowy += gy[t];
			
			start = false;
		}
		
		if (start)
			break;
	}
	
	
	cout << '(' << nowx << ',' << nowy << ')';
}