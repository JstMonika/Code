#include <bits/stdc++.h>
using namespace std;

int s[26];
int m[26];

bool cmp()
{
	for (int i = 0; i < 26; i++)
		if (s[i] != m[i])
			return false;
		
	return true;
}

bool cmpv(const pair<string, int> &a, const pair<string, int> &b)
{
	if (a.second != b.second)
		return a.second > b.second;
	
	return a.first < b.first;
}

int main()
{
	string str, model;
	int n;
	cin >> str >> n >> model;
	
	for (int i = 0; i < n; i++)
	{
		m[model[i] - 'a']++;
		s[str[i] - 'a']++;
	}
	
	if (model.size() == n)
	{
		map<string, int> index;		// substring -> index_in_vector.
		vector< pair<string, int> > ans;	// substring, count.
		
		for (int i = 0; i < str.size() - n + 1; i++)	// i is the starting point of the substring, the length is n.
		{
			if (i)
			{
				s[str[i+n-1] - 'a']++;
				s[str[i-1] - 'a']--;
			}
			
			if(cmp())
			{
				string tmp = str.substr(i, n);	// current substring.
				
				if (index.find(tmp) != index.end())
					ans[index[tmp]].second++;		// index[tmp] --> the index of tmp in the ans vector.
				else
				{
					index[tmp] = index.size();
					ans.emplace_back(tmp, 1);
				}
			}
		}
		
		sort(ans.begin(), ans.end(), cmpv);
		
		cout << ans.size() << endl;
		for (auto i : ans)
			cout << i.first << ' ' << i.second << endl;
	}
	else
		cout << 0 << endl;
}