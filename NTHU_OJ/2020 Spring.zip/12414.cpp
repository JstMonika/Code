#include <bits/stdc++.h>
using namespace std;

int gx[4] = {0, 1, 0, -1};
int gy[4] = {1, 0, -1, 0};

int main()
{
	int cur = 0;
	int idx = 0;
	int x = 0, y = 0;

	int t, tmp;
	while (cin >> t >> tmp)
	{
		x += (t - cur) * gx[idx];
		y += (t - cur) * gy[idx];
		cur = t;

		if (tmp == 1)
			idx = (idx + 3) % 4;
		else if (tmp == 0)
			idx = (idx + 1) % 4;
		else
			break;
	}

	cout << x*10 << ' ' << y*10 << endl;
}