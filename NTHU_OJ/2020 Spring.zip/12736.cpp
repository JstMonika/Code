#include <bits/stdc++.h>
using namespace std;

int n;

#define vvb vector<vector<bool>>
#define vb vector<bool>

class piece
{
	int row, col;
	vvb data;
	
	public:
	
		piece(int r, int c, vvb d) : row(r), col(c), data(d) {}
		int get_row() const { return row; }
		int get_col() const { return col; }
		int get_data(int i, int k) const { return data[i][k]; }
};

vector<piece> items;
vector<int> line;

void print(piece obj)
{
	for (int i = 0; i < obj.get_row(); i++)
	{
		for (int k = 0; k < obj.get_col(); k++)
			cout << obj.get_data(i, k) << ' ';
		cout << endl;
	}
}

bool legal(piece left, piece right, int shift, int dis)
{
	/*
	print(left);
	cout << endl;
	cout << endl;
	print(right);
	cout << endl;
	cout << endl;
	*/
	
	for (int i = 1; i <= shift; i++)
	{
		if (left.get_col() - 1 - shift + i + dis < 0 or left.get_col() - 1 - shift + i + dis >= left.get_col())
			continue;
		if (i-1 >= right.get_col())
			continue;
		
		for (int k = 1; left.get_row() >= k and right.get_row() >= k; k++)
			if (left.get_data(left.get_row() - k, left.get_col() - 1 - shift + i + dis) & right.get_data(right.get_row() - k, i-1))
			// if (left.get_data(left.get_row() - 1 - shift + i, left.get_col() - k) & right.get_data(i-1, right.get_col() - k))
			{
				/*
				cout << "left[" << left.get_row() - k << "][" << left.get_col() - 1 - shift + i
						<< "] and right[" << right.get_row() - k << "][" << i-1 << "] collision." << endl;
				*/
				return false;
			}
	}
	/*
	int lower = min(left.get_col(), right.get_col());
	
	for (int i = 1; i <= shift; i++)
		for (int k = lower-1, m = 0; k >= 0; k--, m++)
		{
			if (left.get_col() < right.get_col())
			{
				if (left.get_data(left.get_row() - 1 + i - shift, k) && right.get_data(i-1, right.get_col()-1-m))
				{
					cout << "left[" << left.get_row()-i << "][" << left.get_col()-1-m
						<< "] and right[" << i-1 << "][" << k << "] collision." << endl;
					return false;
				}
			}
			else
			{
				if (left.get_data(left.get_row() - 1 + i - shift, left.get_col()-1-m) && right.get_data(i-1, k))
				{
					cout << "left[" << left.get_row()-i << "][" << left.get_col()-1-m
						<< "] and right[" << i-1 << "][" << k << "] collision." << endl;
					return false;
				}
			}
		}
	*/		
	return true;
}

int get_width()
{
	int sub = 0;
	int dis[n+1] = {0};
	// cout << "n = " << n << endl;
	for (int i = 1; i < n; i++)
	{
		int shift = 0;
		// cout << i << " and " << i+1 << endl;
		while (true)
		{
			bool jump = false;
			
			for (int k = 0; k < i; k++)
				if (!legal(items[line[k]], items[line[i]], shift, dis[k]))
					jump = true;
			
			if (jump)
				break;
			
			shift++;
		}
		shift--;
		
		for (int k = 0; k < i; k++)
			dis[k] += items[line[i]].get_col() - shift;
		
		sub += shift;
		// cout << "sub = " << sub << endl;
	}	
	
	int count = 0;
	for (int i = 0; i < n; i++)
		count += items[i].get_col();
	count -= sub;
	
	// cout << "count = " << count << endl;
	return count;
}

int main()
{
	cin >> n;
	
	for (int i = 0; i < n; i++)
	{
		int r, c;
		cin >> c >> r;
		
		vvb tmp(r, vb(c));
		for (int i = 0; i < r; i++)
			for (int k = 0; k < c; k++)
			{
				char ch;
				cin >> ch;
				if (ch == 'O')
					tmp[i][k] = true;
				else
					tmp[i][k] = false;
			}
			
		items.push_back(piece(r, c, tmp));
	}
	
	line.resize(n);
	for (int i = 0; i < n; i++)
		line[i] = i;
	
	set<int> exist;
	
	do
	{
		exist.insert(get_width());
		
		/*
		for (int i = 0; i < n; i++)
			cout << line[i] << ' ';
		*/
		// cout << endl;
		// cout << get_width() << endl;
	} while (next_permutation(&line[0], &line[0] + n));
	
	int k;
	cin >> k;
	
	while (k--)
	{
		int request;
		cin >> request;
		
		cout << (exist.count(request) ? "Yes" : "No" ) << endl;
	}
	
	set<int>::iterator it = exist.begin();
	
	// for (; it != exist.end(); it++)
	// 	cout << *it << ' ';
	
}