#include <bits/stdc++.h>
#define DEBUG
using namespace std;

int dead_count;
int ICU_last;

class Matrix_Node
{
	bool type;	// 0 for header node, 1 for pacient node.
	
	string name;
	string status;
	int row, col, value;
	int insert_time;
	int recovery_time;
	
	int prev_Sneighbor;
	int Sneighbor;
	
	bool stay;
	
	bool surrounded;	// more than or equal to 3 sick people.
	int last;	// 0 ~ 7 days.
	
	Matrix_Node* next;
	Matrix_Node* direct[4];		// up, left, down, right.
	
	public:
		Matrix_Node()	// for header node.
		{
			type = false;
			
			row = -10, col = -10;
			
			next = NULL;
			
			for (int i = 0; i < 4; i++)
				direct[i] = this;
		}
		
		Matrix_Node(int r, int c, int v) : row(r), col(c), value(v)	// for header of the header node.
		{
			int size = max(row, col);
			
			Matrix_Node* last = this;
			
			for (int i = 0; i < size; i++)
			{
				last->next = new Matrix_Node();
				last = last->next;
			}
		}
		
		Matrix_Node(string n, int r, int c, int t, string s)	// for pacient node.
		{
			type = true;
			
			name = n;
			status = s;
			row = r;
			col = c;
			insert_time = t;
			
			
			prev_Sneighbor = 0;
			Sneighbor = 0;
			
			stay = false;
			
			if (s == "Sick")
			{
				#ifdef DEBUG
				if (name == "A")
					recovery_time = 5;
				else
				#endif
					recovery_time = 14;
			}
			else
				recovery_time = 0;
			
			surrounded = false;
			last = 0;
			
			for (int i = 0; i < 4; i++)
				direct[i] = NULL;
		}
		
		void insert(const int&, const int&, const int&, const string&, const string&);
		bool neighbor_status(const int&, const string&);
		void traverse(const string&, const int&);
		
		void print();
};

int main()
{
	int map_row, map_col, ICU_capacity, target_time;
	cin >> map_row >> map_col >> ICU_capacity >> target_time;
	
	ICU_last = ICU_capacity;
	
	int pacient_num;
	cin >> pacient_num;
	
	Matrix_Node head(map_row, map_col, pacient_num);
	for (int i = 0; i < pacient_num; i++)
	{
		int time, row, col;
		string name, status;
		
		cin >> time >> row >> col >> name >> status;
		
		head.insert(row, col, time, name, status);
	}
	
	for (int i = 0; i <= target_time; i++)
	{
		// head.traverse("infect", i);	// check the sick neighbors
		
		head.traverse("calculate", i);
		head.traverse("update_sick", i);
		head.traverse("update_healthy", i);
		/*
		
			2.  change state
			
				For sick people:
			
					2.1  recover time-- (if recover == 0 sick -> healthy, reset all counter
			
					2.2  if new sick_neighbor increase ( recovery time + 7 * increase #
			
					2.3  move to ICU if possible
			
					2.3  death_countdown-- ( if death == 0  sick -> dead
			
				For healthy people:
			
					2.1  if sick neighbor nearby ( healthy -> sick recovery time [14 + 7*#sick_neighbor ]
			
					2.2  move to ICU if possible
		*/
		#ifdef DEBUG
		cout << "Day " << i << endl;
		head.print();
		cout << endl;
		#endif
	}
	
	cout << fixed << setprecision(2);
	
	cout << 100.0 * (pacient_num - dead_count) / pacient_num << "%" << endl;
	
	head.print();
}

void Matrix_Node::traverse(const string& str, const int& current)
{
	Matrix_Node* tmp = this;
	while (tmp->next != NULL)
	{
		tmp = tmp->next;
		Matrix_Node* move = tmp;
		
		while (move->direct[3] != tmp)
		{
			move = move->direct[3];
			
			if (move->insert_time >= current)
				continue;
			
			if (str == "calculate")
			{
				move->prev_Sneighbor = move->Sneighbor;
				move->Sneighbor = 0;
				
				for (int i = 0; i < 4; i++)
					if (move->neighbor_status(i, "Sick") and move->direct[i]->insert_time < current)
						move->Sneighbor++;
						
			}
			else if (str == "update_sick")
			{
				if (move->status == "Sick")
				{
					if (--move->recovery_time == 0)
					{
						#ifdef DEBUG
						cout << move->name << " is Healthy at day " << current << endl;
						#endif
						
						move->status = "Healthy";
						move->surrounded = false;
						move->last = 0;
						
						move->stay = true;
						continue;
					}
					
					if (move->Sneighbor > move->prev_Sneighbor and move->status == "Sick")
						move->recovery_time += 7 * (move->Sneighbor - move->prev_Sneighbor);
					
					/*
					for (int i = 0; i < 4; i++)
						if (move->neighbor_status(i, "Sick") and move->direct[i]->insert_time == current-1)
							move->recovery_time += 7;
					*/
						
					if (move->recovery_time > 28 and ICU_last > 0)
					{
						#ifdef DEBUG
						cout << move->name << " go to the ICU at day " << current << endl;
						#endif
						
						move->status = "ICU";
						ICU_last--;
					}
					
					/*
					int count = 0;
					for (int i = 0; i < 4; i++)
						if (move->neighbor_status(i, "Sick") and move->direct[i]->insert_time < current)
							count++;
					*/
					
					if (move->Sneighbor == 4)
					{
						if (move->surrounded)
						{
							move->last--;
							if (move->last == 0)
							{
								move->status = "Dead";
								dead_count++;
								
								#ifdef DEBUG
									cout << move->name << " Dead at day " << current << endl;
								#endif
							}
						}
						else
						{
							move->surrounded = true;
							move->last = 7;
						}
					}
					else
					{
						move->surrounded = false;
						move->last = 0;
					}
				}
			/*}
			else if (str == "update_healthy")
			{*/
				if (move->stay)
				{
					move->stay = false;
					continue;
				}
				
				if (move->status == "Healthy")
				{
					/*
					int count = 0;
					for (int i = 0; i < 4; i++)
					{
						if (move->neighbor_status(i, "Sick") and move->direct[i]->insert_time < current)
							count++;
					}
					*/
					if (move->Sneighbor)
					{
						#ifdef DEBUG
						cout << move->name << " is Sick at day " << current << endl;
						#endif
						
						move->status = "Sick";
						move->insert_time = current;
						move->recovery_time = 14 + move->Sneighbor * 7;
					}
					
					if (move->recovery_time > 28 and ICU_last > 0)
					{
						#ifdef DEBUG
						cout << move->name << " go to the ICU at day " << current << endl;
						#endif
						
						move->status = "ICU";
						ICU_last--;
					}
				}
			}
		}
	}
}

bool Matrix_Node::neighbor_status(const int& i, const string& str)
{
	switch (i)
	{
		case 0:
			if (this->direct[0]->row == this->row - 1 && this->direct[0]->col == this->col)
			{
				if (this->direct[0]->status == str)
					return true;
				else
					return false;
			}
			
			return false;
		case 1:
			if (this->direct[1]->row == this->row && this->direct[1]->col == this->col - 1)
			{
				if (this->direct[1]->status == str)
					return true;
				else
					return false;
			}
			
			return false;
		case 2:
			if (this->direct[2]->row == this->row + 1 && this->direct[2]->col == this->col)
			{
				if (this->direct[2]->status == str)
					return true;
				else
					return false;
			}
			
			return false;
		case 3:
			if (this->direct[3]->row == this->row&& this->direct[3]->col == this->col + 1)
			{
				if (this->direct[3]->status == str)
					return true;
				else
					return false;
			}
			
			return false;
	}
}

void Matrix_Node::print()	// only for header of headers.
{
	bool first = true;
	
	Matrix_Node* tmp = this;
	while (tmp->next != NULL)
	{
		#ifndef DEBUG
		tmp = tmp->next;
		Matrix_Node* move = tmp;
		
		while (move->direct[3] != tmp)
		{
			move = move->direct[3];
			
			if (move->status != "Dead" and move->status != "ICU")
			{
				if (first)
					first = false;
				else
					cout << ' ';
		
				cout << move->name;
			}
		}
		#endif
		
		#ifdef DEBUG
		tmp = tmp->next;
		Matrix_Node* move = tmp;
		
		while (move->direct[3] != tmp)
		{
			move = move->direct[3];
			
			cout << move->name << ' ' << move->status << ' ' << move->recovery_time << endl;
			// cout << "S = " << move->Sneighbor << endl;
		}
		#endif
	}
}

void Matrix_Node::insert(const int& r, const int& c, const int& t, const string& n, const string& s)
{
	Matrix_Node* row_head = this, *col_head = this;
	for (int i = 0; i < r; i++) row_head = row_head->next;
	for (int i = 0; i < c; i++) col_head = col_head->next;
	
	Matrix_Node* cur = new Matrix_Node(n, r, c, t, s);
	
	while (row_head->direct[3]->type and row_head->direct[3]->col < c) row_head = row_head->direct[3];
	cur->direct[3] = row_head->direct[3];
	cur->direct[3]->direct[1] = cur;
	row_head->direct[3] = cur;
	cur->direct[1] = row_head;
	
	while (col_head->direct[2]->type and col_head->direct[2]->row < r) col_head = col_head->direct[2];
	cur->direct[2] = col_head->direct[2];
	cur->direct[2]->direct[0] = cur;
	col_head->direct[2] = cur;
	cur->direct[0] = col_head;
}

