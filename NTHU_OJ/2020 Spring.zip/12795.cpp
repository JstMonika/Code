#include <bits/stdc++.h>
using namespace std;
int point;
int graph[50][50];
int dist[50];
bool sptSet[50];
int parent[50];

int minDistance(int dist[], bool sptSet[]){ 
	
	// Initialize min value 
	int min = INT_MAX, min_index; 

	for (int v = 0; v < point; v++) 
		if (sptSet[v] == false and dist[v] <= min) 
			min = dist[v], min_index = v; 

	return min_index; 
} 
 
void printPath(int j){ 
	char tmp[50];
	int count = 0;
	
	while (parent[j] != -1)
	{
		tmp[count++] = 'A' + j;
		j = parent[j];
	}
	
	for (int i = count-1; i >= 0; i--)
		cout << ' ' << tmp[i];
} 

int printSolution(int dist[], int n, int parent[], int source, int destination){
	
		cout << dist[destination] << endl; 
		char tmp = 'A' + source;
		cout << tmp;
		printPath(destination); 
} 

void dijkstra(int src){ 

	for (int i = 0; i < point; i++){ 
		parent[src] = -1; 
		dist[i] = INT_MAX; 
		sptSet[i] = false; 
	} 

	dist[src] = 0; 

	for (int count = 0; count < point - 1; count++){
		int u = minDistance(dist, sptSet); 
		sptSet[u] = true; 

		for (int v = 0; v < point; v++)
			if (!sptSet[v] and graph[u][v] and dist[u] + graph[u][v] < dist[v]){ 
				parent[v] = u; 
				dist[v] = dist[u] + graph[u][v]; 
			} 
	} 
} 

int main(){
	int edge,distance;
	cin >> point >> edge;
	char source,destination;
	cin >> source >> destination;
	while(edge--){
		char tmp1,tmp2;
		cin >> tmp1 >> tmp2 >> distance;
		graph[tmp1-'A'][tmp2-'A'] = distance;
		graph[tmp2-'A'][tmp1-'A'] = distance;
	}
	/*for(int i=0;i<5;i++){
		for(int j=0;j<5;j++)
			cout << w[i][j] << " ";
		cout << endl;
	}*/

	dijkstra(source-'A');
	printSolution(dist, point, parent,source-'A',destination-'A');
} 
