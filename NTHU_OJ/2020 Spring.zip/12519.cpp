#include <bits/stdc++.h>
using namespace std;

bool cmp(const pair<string, int> &a, const pair<string, int> &b)
{
	if (a.second != b.second)
		return a.second > b.second;
	
	return a.first < b.first;
}

int main()
{
	int n;
	string template_str;
	cin >> n >> template_str;
	
	int temp[30];
	int target[30];
	
	map<string, int> ans;
	while (n--)
	{
		memset(temp, 0, sizeof temp);
		memset(target, 0, sizeof target);
		
		string str;
		cin >> str;
		
		if (str.size() != template_str.size())
			continue;
		
		int count = 1;
		bool good = true;
		for (int i = 0; i < str.size(); i++)
		{
			if (temp[template_str[i] - 'a'] != target[str[i] - 'a'])
				good = false;
			
			if (!target[str[i] - 'a'])
				target[str[i] - 'a'] = temp[template_str[i] - 'a'] = count++;
		}
		
		if (good)
			ans[str]++;
	}
	
	
	vector< pair<string, int> > v_ans;
	map<string, int>::iterator it;
	cout << ans.size() << endl;
	for (it = ans.begin(); it != ans.end(); it++)
		v_ans.emplace_back(it->first, it->second);
	
	sort(v_ans.begin(), v_ans.end(), cmp);
	
	for (auto i : v_ans)
		cout << i.first << ' ' << i.second << endl;
}