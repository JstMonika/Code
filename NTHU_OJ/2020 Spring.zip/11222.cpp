#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin >> n;

	vector<int> column(n);
	for (int i = 0; i < n; i++)
		column[i] = i;

	int count = 0;

	do
	{
		int good = true;

		for (int i = 0; i < n; i++)
			for (int k = i+1; k < n; k++)
				if (abs(column[k] - column[i]) == abs(k-i))
					good = false;

		if (good)
			count++;

	} while (next_permutation(column.begin(), column.end()));
	
	cout << count;
}