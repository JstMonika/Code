#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	scanf("%d", &n);
	n++;
	
	int nmax = numeric_limits<int>::min();
	int nmin = numeric_limits<int>::max();
	
	while (n--)
	{
		int tmp;
		scanf("%d", &tmp);
		
		nmax = (nmax > tmp) ? nmax : tmp;
		nmin = (nmin < tmp) ? nmin : tmp;
	}
	
	printf("%d\n", 2*(nmax-nmin));
}