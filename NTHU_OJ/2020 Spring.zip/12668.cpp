#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

struct node
{
	char ch;
	node* next;
	node* prev;
};

int main()
{
	int c;
	scanf("%d", &c);
	
	while (c--)
	{
		node* start = (node*) malloc(sizeof(node));
		start->next = NULL;
		start->prev = NULL;
		
		int n;
		scanf("%d", &n);
		
		char _list[n+1];
		scanf("%s", _list);
		
		node* current = start;
		for (int i = 0; i < n; i++)
		{
			if (islower(_list[i]))
			{
				node* tmpnext = current->next;
				
				current->next = (node*) malloc(sizeof(node));
				node* tmp = current;
				
				current = current->next;
				current->prev = tmp;
				current->ch = _list[i];
				current->next = tmpnext;
				
				if (current->next != NULL)
					(current->next)->prev = current;
			}
			
			else if (_list[i] == 'B')
			{
				(current->prev)->next = current->next;
				
				if (current->next != NULL)
					(current->next)->prev = current->prev;
				
				node* tmp = current;
				current = current->prev;
				
				free(tmp);
			}
			else if (_list[i] == 'L')
			{
				if (current->prev != NULL)
					current = current->prev;
			}
			else
			{
				if (current->next != NULL)
					current = current->next;
			}
		}
		
		int first = 1;
		while (start != NULL)
		{
			if (first)
				first = 0;
			else
				printf("%c", start->ch);
			
			node* tmp = start;
			start = start->next;
			
			free(tmp);
		}
		
		printf("\n");
	}
}