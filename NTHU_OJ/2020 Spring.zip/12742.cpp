#include "function.h"

Graph::Graph(int n)
{
	numberOfVertices = n;
	
	adjacencyList = new Vertex*[n];
	
	for (int i = 0; i < n; i++)
		adjacencyList[i] = new Vertex();
}
// TODO: Implement function to add edge from srouce to destination, you can insert Vertex destination at the front of the list of adjacencyList[source]
void Graph::addEdge(int source, int destination)
{
	Vertex* cur = adjacencyList[source];
	
	while (cur->next != nullptr)
		cur = cur->next;
	
	cur->next = new Vertex(destination);
}
// TODO: Implement a depth first search on the graph to solve the problem
bool Graph::dfs(int vertex)
{
	if (adjacencyList[vertex].index == 0)
		return true;;
	
	if (*vertexInfo == -1)
		adjacencyList[vertex].index = -2;
	else
		adjacencyList[vertex].index = -1;
	
	vertexInfo = &(adjacencyList[vertex].index);
	
	Vertex* cur = adjacencyList[vertex];
	while (cur->next != nullptr)
	{
		cur = cur->next;
		dfs(cur);
	}
	
	return true;
}
// TODO: Implement your solver function
bool Graph::solver()
{
	adjacencyList[0].index = -1;
	vertexInfo = &(adjacencyList[0].index);
	dfs(0);
	
	for (int i = 0; i < numberOfVertices; i++)
	{
		int base = adjacencyList[i].index;
		
		Vertex* cur = adjacencyList[i];
		while (cur->next != nullptr)
		{
			if (cur->next->index == base)
				return false;
			
			cur = cur->next;
		}
	}
	
	return true;
}
// TODO: Implement the destructor
Graph::~Graph()
{
	for (int i = 0; i < n; i++)
	{
		Vertex* cur = adjacencyList[i];
		while (cur != nullptr)
		{
			Vertex* del = cur;
			cur = cur->nextVertex;
			
			delete del;
		}
	}
	
	delete [] adjacencyList;
}