#include <bits/stdc++.h>
using namespace std;

int main()
{
	string str;
	getline(cin, str);
	
	vector<char> ans;
	
	int ptr = 0;
	for (int i = 0; i < str.size(); i++)
	{
		if (str[i] == '/')
		{
			switch (str[i+1])
			{
				case 'b':
					if (ans.size() and ptr)
					{
						ans.erase(ans.begin() + (ptr-1));
						ptr--;
					}
					
					i += 9;
					break;
				case 'n':
					ans.insert(ans.begin() + ptr, '\n');
					ptr++;
					
					i += 7;
					break;
				case 'l':
					if (ptr)
						ptr--;
					
					i += 4;
					break;
				case 'r':
					if (ptr < ans.size())
						ptr++;
					
					i += 5;
					break;
			}
		}
		else
		{
			ans.insert(ans.begin() + ptr, str[i]);
			ptr++;
		}
	}
	
	for (int i = 0; i < ans.size(); i++)
		cout << ans[i];
}