#include <bits/stdc++.h>
using namespace std;

using vp = vector<pair<int, int>>;

bool exist[16][301][401];

struct status
{
	int time;
	int lv;
	int curHP;
	int monHP;
	status(int t, int l, int c, int m) : time(t), lv(l), curHP(c), monHP(m) {}
};

vp _list;
int maxLV;
int maxHP;


int main()
{
	int monsHP, monsATK;
	cin >> maxLV >> maxHP >> monsHP >> monsATK;

	_list.resize(maxLV+1);
	for (int i = 1; i <= maxLV; i++)
		cin >> _list[i].first >> _list[i].second;

	queue<status> next;
	next.push(status(0, 1, maxHP, monsHP));

	while (!next.empty())
	{
		status now = next.front();
		next.pop();

		if (exist[now.lv][now.curHP][now.monHP])
			continue;
		
		exist[now.lv][now.curHP][now.monHP] = true;

		// atk.
		status tmp = now;

		tmp.monHP -= _list[tmp.lv].first;

		if (tmp.monHP <= 0)
		{
			cout << tmp.time+1 << endl;
			break;
		}

		tmp.curHP -= monsATK;

		if (tmp.curHP > 0)
		{
			tmp.time++;
			next.push(tmp);
		}

		// upgrade.
		tmp = now;

		if (tmp.lv != maxLV)
			tmp.lv++;

		tmp.curHP -= monsATK;

		if (tmp.curHP > 0)
		{
			tmp.time++;
			next.push(tmp);
		}

		// heal.
		tmp = now;

		tmp.curHP += _list[tmp.lv].second;

		tmp.curHP = min(tmp.curHP, maxHP);

		tmp.curHP -= monsATK;

		if (tmp.curHP > 0)
		{
			tmp.time++;
			next.push(tmp);
		}
	}
}
