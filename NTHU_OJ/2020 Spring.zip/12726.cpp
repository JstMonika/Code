#include <bits/stdc++.h>
using namespace std;

bool good = 0;

#define vb vector<bool>
#define vvb vector<vector<bool>>
#define vp vector<piece>

bool** rectangle(int i, int k)
{
	bool** ptr = new bool*[i];
	
	for (int m = 0; m < i; m++)
		ptr[m] = new bool[k];
	
	return ptr;
}

class piece
{
	int row, col;
	bool** data;
	// vvb data;
	
	public:
		int get_row() const { return row; }
		int get_col() const { return col; }
		bool get_data(int i, int k) const { return data[i][k]; }
		
		piece(int r, int c, bool** d) : row(r), col(c), data(d) {}
		// piece(int r, int c, vvb d) : row(r), col(c), data(d) {}
		
		void rotate();
		void flip();
};

vp items;

class puzzle
{
	int row, col;
	bool** data;
	// vvb data;
	int blank;
	
	public:
		int get_row() const { return row; }
		int get_col() const { return col; }
		int get_count() const { return blank; }
		bool get_data(int i, int k) const { return data[i][k]; }
		
		// vvb all_data() const { return data; }
		
		puzzle(int r, int c, bool** d, int b) : row(r), col(c), data(d), blank(b) {}
		// puzzle(int r, int c, vvb d, int b) : row(r), col(c), data(d), blank(b) {}
		bool full() const { return (blank == row * col); }
		bool legal(piece, int, int) const;
		puzzle put(piece, int, int) const;
};

vvb madevvb(piece obj)
{
	vvb tmp(obj.get_row(), vb(obj.get_col()));
	
	for (int i = 0; i < obj.get_row(); i++)
		for (int k = 0; k < obj.get_col(); k++)
			tmp[i][k] = obj.get_data(i, k);
		
	return tmp;
}

void DFS(puzzle cur, int num)
{
	set< vvb > exist;
	
	if (num == items.size())
	{
		if (cur.full())
			good = 1;
		
		return;
	}
	
	for (int i = 0; i < 8; i++)
	{
		if (exist.count(madevvb(items[num])))
			continue;
		
		exist.insert(madevvb(items[num]));
		
		for (int x = 0; x < cur.get_row(); x++)
			for (int y = 0; y < cur.get_col(); y++)
				if (cur.legal(items[num], x, y) and !good)
					DFS(cur.put(items[num], x, y), num+1);
		
		items[num].rotate();
		
		if (i == 3 or i == 7)
			items[num].flip();
	}
	
	exist.clear();
}

bool puzzle::legal(piece obj, int x, int y) const
{
	if (obj.get_row() + x > get_row())
		return false;
	if (obj.get_col() + y > get_col())
		return false;
	
	for (int i = 0; i < obj.get_row(); i++)
		for (int k = 0; k < obj.get_col(); k++)
			if (obj.get_data(i, k) && get_data(i+x, k+y))
				return false;
		
	return true;
}

puzzle puzzle::put(piece obj, int x, int y) const
{
	int count = 0;
	
	bool** ptr = rectangle(get_row(), get_col());
	// vvb tmp = all_data();
	
	for (int i = 0; i < get_row(); i++)
		for (int k = 0; k < get_col(); k++)
			ptr[i][k] = data[i][k];
		
	for (int i = 0; i < obj.get_row(); i++)
		for (int k = 0 ; k < obj.get_col(); k++)
			if (obj.get_data(i, k))
			{
				ptr[i+x][k+y] = 1;
				count++;
			}
	
	puzzle new_one(get_row(), get_col(), ptr, get_count() + count);
	
	return new_one;
}

void piece::rotate()
{
	bool** tmp = rectangle(get_col(), get_row());
	// vvb tmp(get_col(), vb(get_row()));
	
	for (int i = 0; i < get_row(); i++)
	{
		for (int k = 0; k < get_col(); k++)
			tmp[k][row-1-i] = data[i][k];
		
		delete [] data[i];
	}
			
	int numtmp = row;
	row = col;
	col = numtmp;
	
	delete [] data;
	
	data = tmp;
}

void piece::flip()
{
	for (int i = 0; i < get_row(); i++)
		for (int k = 0; k < get_col()/2; k++)
		{
			int t = data[i][col-1-k];
			data[i][col-1-k] = data[i][k];
			data[i][k] = t;
		}
}

int main()
{
	int n;
	cin >> n;
	
	
	for (int i = 0; i < n; i++)
	{
		int c, r;
		cin >> c >> r;
		
		char ch;
		
		bool** tmp = rectangle(r, c);
		// vvb tmp(r, vb(c));
		for (int i = 0; i < r; i++)
			for (int k = 0; k < c; k++)
			{
				cin >> ch;
				tmp[i][k] = (ch == 'O') ? 1 : 0;
			}
			
		items.push_back(piece(r, c, tmp));
	}
	
	int m;
	cin >> m;
	while (m--)
	{
		good = 0;
		
		int c, r, count = 0;
		cin >> c >> r;
		
		char ch;
		
		bool** tmp = rectangle(r, c);
		// vvb tmp(r, vb(c));
		for (int i = 0; i < r; i++)
			for (int k = 0; k < c; k++)
			{
				cin >> ch;
				
				tmp[i][k] = (ch == 'O') ? 1 : 0;
				
				if (ch == 'O')
					count++;
			}
			
		puzzle cur(r, c, tmp, count);
		
		DFS(cur, 0);
		
		cout << ((good) ? "Yes" : "No") << endl;
	}
}