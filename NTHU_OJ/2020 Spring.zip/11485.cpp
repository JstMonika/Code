#include <bits/stdc++.h>
using namespace std;

using vi = vector<int>;

void outvec(const vi& v)
{
	for (auto i : v)
		cout << i << ' ';
	cout << endl;
}

int cal(const vi& v)
{
	int count = 0;
	
	for (int i = 0; i < v.size(); i++)
		count += v[i] * (v.size() - i);
	
	return count;
}

int main()
{
	auto cmp = [](vi a, vi b) { return cal(a) < cal(b); };
	
	set<vi, decltype(cmp)> S(cmp);
	
	string command;
	
	while (cin >> command)
	{
		if (command == "output")
		{
			for (auto it = S.begin(); it != S.end(); it++)
				outvec(*it);
		}
		else if (command == "range_out")
		{
			int border[2];
			int num;
			
			for (int i = 0; i < 2; i++)
			{
				vi tmp;
				while (cin >> num)
				{
					if (num)
						tmp.push_back(num);
					else
						break;
				}
				
				border[i] = cal(tmp);
			}
			
			for (auto it = S.begin(); it != S.end(); it++)
				if (cal(*it) >= border[0] and cal(*it) <= border[1])
					outvec(*it);
		}
		else if (command == "insert")
		{
			vi tmp;
			int num;
			while (cin >> num)
			{
				if (num)
					tmp.push_back(num);
				else
					break;
			}
			
			for (auto it = S.begin(); it != S.end(); it++)
			{
				if (cal(*it) == num)
				{
					cout << "exist" << endl;
					reverse(tmp.begin(), tmp.end());
					
					S.erase(it);
					break;
				}
			}
			
			S.insert(tmp);
		}
	}
}