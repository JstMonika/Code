#include <bits/stdc++.h>
using namespace std;

vector<string> name(1000);
vector<int> grade(1000);
vector<int> age(1000);

void swap(int i, int k)
{
	string tmp;
	tmp = name[i];
	name[i] = name[k];
	name[k] = tmp;
	
	int t = grade[i];
	grade[i] = grade[k];
	grade[k] = t;
	
	t = age[i];
	age[i] = age[k];
	age[k] = t;
}

int main()
{
	int n, m;
	cin >> n >> m;
	
	for (int i = 0; i < n; i++)
		cin >> name[i] >> grade[i] >> age[i];
	
	for (int i = 0; i < n; i++)
		for (int k = i+1; k < n; k++)
		{
			if (grade[i] > grade[k])
				swap(i, k);
			else if (grade[i] == grade[k])
			{
				if (age[i] < age[k])
					swap(i, k);
				else if (age[i] == age[k])
				{
					if (name[i] < name[k])
						swap(i, k);
				}
			}
		}
		
	for (int i = 0; i < m; i++)
		cout << name[i] << endl;
}