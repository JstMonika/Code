#include <bits/stdc++.h>
using namespace std;

int ans = numeric_limits<int>::max();
int n;

vector< vector<int> > dis(10, vector<int>(10));
vector<bool> done;

int go(int node, int count, int sum)
{
	if (count == n)
		ans = min(ans, sum+dis[node][0]);
	
	done[node] = true;
	
	for (int i = 0; i < n; i++)
		if (!done[i])
			go(i, count+1, sum+dis[node][i]);
		
	done[node] = false;
}

int main()
{
	cin >> n;
	
	for (int i = 0; i < n; i++)
		for (int k = 0; k < n; k++)
			cin >> dis[i][k];
		
	done.resize(n);
	
	go(0, 1, 0);
	
	cout << ans << endl;
}