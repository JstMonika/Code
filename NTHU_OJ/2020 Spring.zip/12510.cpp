#include <bits/stdc++.h>
using namespace std;

int r, c;
char mapp[1005][1005];
bool done[1005][1005];
bool good = false;
bool teleport_done = false;
vector< pair<int, int> > tp;

queue< pair<int, int> > waiting;

int gx[4] = {0, 0, -1, 1};
int gy[4] = {1, -1, 0, 0};

bool valid(int i, int k)
{
	if (i <= 0 or i > r)
		return false;
	if (k <= 0 or k > c)
		return false;
	if (mapp[i][k] == '#')
		return false;
	if (done[i][k])
		return false;
	
	return true;
}

void bfs(int i, int k)
{
	if (i == r and k == c)
		good = true;
	
	for (int m = 0; m < 4; m++)
		if (valid(i+gx[m], k+gy[m]))
		{
			done[i+gx[m]][k+gy[m]] = true;
			waiting.emplace(i+gx[m], k+gy[m]);
		}
		
	if (mapp[i][k] == 'T' and !teleport_done)
	{
		teleport_done = true;
		
		for (int m = 0; m < tp.size(); m++)
			if (valid(tp[m].first, tp[m].second))
			{
				done[tp[m].first][tp[m].second] = true;
				waiting.emplace(tp[m].first, tp[m].second);
			}
	}
}

int main()
{
	int cases;
	cin >> cases;
	
	while (cases--)
	{
		good = false;
		teleport_done = false;
		tp.clear();
		
		cin >> r >> c;
		
		for (int i = 1; i <= r; i++)
			for (int k = 1; k <= c; k++)
			{
				cin >> mapp[i][k];
				done[i][k] = false;
				
				if (mapp[i][k] == 'T')
					tp.emplace_back(i, k);
			}
			
		done[1][1] = true;
		bfs(1, 1);
		while (waiting.size())
		{
			int i = waiting.front().first;
			int k = waiting.front().second;
			waiting.pop();
			bfs(i, k);
		}
		
		if (good)
			cout << "Yes" << endl;
		else
			cout << "No" << endl;
	}
}