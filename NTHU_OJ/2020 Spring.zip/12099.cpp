#include <bits/stdc++.h>
using namespace std;

int main()
{
	vector<string> str(200000);
	
	int i = 0;
	while (cin >> str[i])
		i++;
	
	sort(str.begin(), str.end());
	for (int k = 200000-i; k < 200000; k++)
		cout << str[k] << '\n';
}