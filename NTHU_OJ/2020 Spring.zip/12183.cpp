#include <bits/stdc++.h>
using namespace std;

struct Node
{
	int op;
	int result;
	
	Node* left;
	Node* right;
	Node* parent;
};

Node* address[100001];

Node* prefix()
{
	Node* head = (Node*) malloc(sizeof(Node));
	head->result = 0;
	
	char ch;
	scanf(" %c", &ch);
	
	if (ch == '|')
	{
		head->op = -1;
		
		head->left = prefix();
		head->left->parent = head;
		
		head->right = prefix();
		head->right->parent = head;
		
		head->result = head->left->result | head->right->result;
	}
	else if (ch == '&')
	{
		head->op = -2;
		
		head->left = prefix();
		head->left->parent = head;
		
		head->right = prefix();
		head->right->parent = head;
		
		head->result = head->left->result & head->right->result;
	}
	else
	{
		scanf("%d]", &head->op);
		address[head->op] = head;

		head->left = NULL;
		head->right = NULL;
	}
	
	return head;
}

void fix(Node* head)
{
	if (head->left == NULL and head->right == NULL)
		head->result = !head->result;
	else
	{
		if (head->op == -1)
			head->result = head->left->result | head->right->result;
		else
			head->result = head->left->result & head->right->result;
	}
	
	if (head->parent != NULL)
		fix(head->parent);
}

int main()
{
	int c;
	cin >> c;
	
	while (c--)
	{
		int n, m;
		cin >> n >> m;
		
		Node* root = prefix();
		
		for (int i = 0; i < m; i++)
		{
			int tmp;
			cin >> tmp;
			
			fix(address[tmp]);
			
			cout << root->result << endl;
		}
	}
}