#include <bits/stdc++.h>
using namespace std;

#define pii pair<int, int>

int main()
{
	int r, c;
	cin >> r >> c;
	
	pii us, boss;
	cin >> us.first >> us.second;
	cin >> boss.first >> boss.second;
	
	vector< vector<
}