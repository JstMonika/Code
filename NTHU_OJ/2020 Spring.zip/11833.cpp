#include <bits/stdc++.h>
using namespace std;

vector<int> pos;
vector<int> post;
int idx = 0;

struct Node
{
	int num;
	
	Node* left;
	Node* right;
};

Node* maketree(int left, int right)
{
	if (left > right)
		return NULL;
	
	Node* head = (Node*) malloc(sizeof(Node));
	
	head->num = post[idx];
	int tmp = pos[post[idx++]];
	
	head->left = maketree(left, tmp-1);
	head->right = maketree(tmp+1, right);
	
	return head;
}

void print(Node* head)
{
	if (head == NULL)
		return;
	
	print(head->left);
	print(head->right);
	
	cout << head->num << ' ';
}

int main()
{
	int n;
	cin >> n;
	
	pos.resize(n);
	post.resize(n);
	for (int i = 0; i < n; i++)
	{
		int tmp;
		cin >> tmp;
		pos[tmp] = i;
	}
	
	for (int i = 0; i < n; i++)
		cin >> post[i];
	
	Node* root = maketree(0, n-1);
	
	print(root);
	
	cout << endl;
}