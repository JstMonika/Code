#include<stdio.h>
const int mod=1e9+7;

typedef struct matrix
{
    long long a[5][5];

    void ret()//每次要乘的陣列
    {
        a[0][0]=1;a[0][1]=2;a[0][2]=1;
        a[1][0]=1;a[1][1]=0;a[1][2]=0;
        a[2][0]=0;a[2][1]=1;a[2][2]=0;
    }

} A;

matrix mul(matrix a,matrix b) //(A*B)
{
    matrix ans;
    ans.ret();
    for(int i=0;i<=2;i++)
    {
        for(int j=0;j<=2;j++)
        {
            ans.a[i][j]=0;
            for(int k=0;k<=2;k++)
                ans.a[i][j]+=a.a[i][k]*b.a[k][j];
                ans.a[i][j]%=mod;
        }
    }
    return ans;
}

matrix power(matrix a,long long n) //(a^n)%mod
{
    matrix ans;
    ans.ret();

    while(n)
    {
        if(n%2)
            ans=mul(ans,a);

        n/=2;
        a=mul(a,a);
    }
    return ans;
}

int main()
{
    int t;
    long long x;
    scanf("%d",&t);
    while(t--)
    {

        scanf("%lld",&x);
        mul(power(A,x-3),a);
        output = a[0][0]*1+a[0][1]*12+a[0][2]*13;
        output%=mod;

        printf("%lld\n",output);
    }
}
