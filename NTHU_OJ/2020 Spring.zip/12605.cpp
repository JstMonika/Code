#include <bits/stdc++.h>
using namespace std;

int main()
{
	int change[26];
	
	for (int i = 0; i < 26; i++)
		change[i] = i + 'a';
	
	int len, command;
	cin >> len >> command;
	
	string str;
	cin >> str;
	
	while (command--)
	{
		char chara, charb;
		
		cin >> chara >> charb;
		
		for (int i = 0; i < 26; i++)
		{
			if (change[i] == chara)
				change[i] = charb;
			else if (change[i] == charb)
				change[i] = chara;
		}
	}
	
	for (int i = 0; i < len; i++)
		cout << char(change[str[i] - 'a']);
	
	cout << endl;
}