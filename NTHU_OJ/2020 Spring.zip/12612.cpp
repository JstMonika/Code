#include <bits/stdc++.h>
using namespace std;

int main()
{
	char str[10010];
	scanf("%s", str);
	
	int c;
	scanf("%d", &c);
	
	while (c--)
	{
		int l, r, t;
		scanf("%d%d%d", &l, &r, &t);
		
		l--;
		r--;
		
		char tmp[r-l+1];
		for (int i = 0; i < r-l+1; i++)
			tmp[i] = str[l+i];
		
		for (int i = 0; i < r-l+1; i++)
			str[((i+t) % (r-l+1)) + l] = tmp[i];
	}
	
	printf("%s\n", str);
}