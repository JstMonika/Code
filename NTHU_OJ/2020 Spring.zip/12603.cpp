#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	cin >> n;
	
	
	if (n >= 2)
	{
		string str;
		cin >> str;
		
		int nmin = numeric_limits<int>::max();
		
		int prev, next;
		cin >> prev >> next;
		
		for (int i = 0; i < str.size()-1; i++)
		{
			if (str[i] == 'R' and str[i+1] == 'L')
				nmin = min(nmin, (next-prev)/2);
			
			prev = next;
			cin >> next;
		}
		
		cout << ((nmin == numeric_limits<int>::max()) ? -1 : nmin) << endl;
	}
	else
		cout << -1 << endl;
}