#include <bits/stdc++.h>
using namespace std;

long long count(int y, int n)
{
	if (!n)
		return 1;
	
	if (n%2 == 0)
		return (count(y, n/2) * count(y, n/2)) % 10177;
	else
		return (count(y, n/2) * count(y, n/2) * y) % 10177;
}

int main()
{
	long long x, y, n;
	while (cin >> x >> y >> n)
		cout << (x * count(y+1, n-1)) % 10177 << endl;
}