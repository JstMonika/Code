#include <bits/stdc++.h>
using namespace std;
string str;
bool first = true;

double prefix()
{
	if (isdigit(cin.peek()))
	{
		int a;
		cin >> a;
		cin.get();
		
		cout << ' ' << a;
		
		return a;
	}
	else
	{
		char ch;
		cin >> ch;
		cin.get();
		
		if (first)
		{
			cout << "(";
			first = false;
		}
		else
			cout << " (";
		
		double a, b;
		a = prefix();
		
		cout << ' ' << ch;
		
		b = prefix();
		
		cout << " )";
		
		switch (ch)
		{
			case '+':
				return a+b;
				
			case '-':
				return a-b;
				
			case '*':
				return a*b;
				
			case '/':
				return a/b;
		}
	}
}

int main()
{
	int c;
	cin >> c;
	cin.get();
	
	while (c--)
	{
		first = true;
		double ans = prefix();
		// cout << "ans = " << ans << endl;
		if (ans == int(ans))
			printf(" = %.0f\n", ans);
		else
			printf(" = %.1f\n", ans);
	}
}