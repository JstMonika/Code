#include <bits/stdc++.h>
using namespace std;

int n;
char mapp[101][101];
int done[101][101][10];
string sample = "ICPCASIASG";
bool found = false;

void dfs(int i, int k, int d)
{
	// cout << "{" << i << ", " << k << ", " << d << "}\n";
	
	if (done[i][k][d])
		return;
	if (d == 9)
	{
		found = true;
		return;
	}
	
	done[i][k][d] = 1;
	
	int gx[8] = {1, 1, 2, 2, -1, -1, -2, -2};
	int gy[8] = {2, -2, 1, -1, 2, -2, 1, -1};
	
	for (int m = 0; m < 8; m++)
	{
		if (i + gx[m] <= 0 or i + gx[m] > n)
			continue;
		if (k + gy[m] <= 0 or k + gy[m] > n)
			continue;
		if (mapp[i+gx[m]][k+gy[m]] != sample[d+1])
			continue;
		
		dfs(i+gx[m], k+gy[m], d+1);
	}
}

int main()
{
	cin >> n;
	
	for (int i = 1; i <= n; i++)
		for (int k = 1; k <= n; k++)
			cin >> mapp[i][k];
		
	for (int i = 1; i <= n; i++)
		for (int k = 1; k <= n; k++)
			if (mapp[i][k] == 'I')
				dfs(i, k, 0);
			
	if (found)
		cout << "YES" << endl;
	else
		cout << "NO" << endl;
}