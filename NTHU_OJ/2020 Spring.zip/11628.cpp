#include <bits/stdc++.h>
using namespace std;

char graph[5001][5001];
int gx[4] = {0, 1, 0, -1};
int gy[4] = {1, 0, -1, 0};

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	
	int c;
	cin >> c;
	
	while (c--)
	{
		int n;
		cin >> n;
		
		for (int i = 0; i < n; i++)
			for (int k = 0; k < n; k++)
				graph[i][k] = ' ';
			
		int idx = 0, x = 0, y = -1;
		for (int i = n; i > 0; i--)
		{
			for (int k = 0; k < i; k++)
			{
				x += gx[idx];
				y += gy[idx];
				
				graph[x][y] = '#';
			}
			
			idx = (idx + 1) % 4;
		}
		
		for (int i = 0; i < n; i++)
		{
			for (int k = 0; k < n; k++)
				cout << graph[i][k];
			
			cout << '\n';
		}
	}
}