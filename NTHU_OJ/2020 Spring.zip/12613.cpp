#include <bits/stdc++.h>
using namespace std;

int main()
{
	int c;
	cin >> c;
	
	while (c--)
	{
		long long a, b;
		cin >> a >> b;
		
		int bc = 1;
		while (b / 10)
		{
			b /= 10;
			bc++;
		}
		
		// cout << "bc = " << bc << endl;
		
		long long ans = a * (bc-1);
		cout << ans << endl;
	}
}