#include <bits/stdc++.h>
using namespace std;

struct Book
{
	int number;
	Book* next;
	Book* prev;
};

// create an array stores where the book is.
vector<int> where;
// table.
vector<Book*> table;
// the top of table.
vector<Book*> top_table;
// book address.
vector<Book*> location;

int main()
{
	int n;
	cin >> n;
	
	where.resize(n);
	table.resize(n);
	top_table.resize(n);
	location.resize(n);
	
	for (int i = 0; i < n; i++)
	{
		where[i] = i;
		
		table[i] =  (Book*) malloc(sizeof(Book));
		Book* tmp = (Book*) malloc(sizeof(Book));
		
		tmp->number = i;
		tmp->next = NULL;
		tmp->prev = table[i];
		
		location[i] = tmp;
		top_table[i] = tmp;
		
		table[i]->number = -1 * i - 1;
		table[i]->next = tmp;
		table[i]->prev = NULL;
	}
	
	// initialize finished.
	
	char command[2][10];
	int input[2];
	
	while (true)
	{
		scanf("%s", command[0]);
		
		if (!strcmp(command[0], "exit"))
			break;
		
		scanf("%d%s%d", &input[0], command[1], &input[1]);
		
		if (where[input[0]] == where[input[1]])		// same table.
			continue;
		
		if (!strcmp(command[0], "move"))
		{
			if (!strcmp(command[1], "onto"))		// move onto.
			{
				Book* cur = top_table[where[input[0]]];
				while (cur != location[input[0]])
				{	
					Book* tmp = cur->prev;
					tmp->next = cur->next;
					
					cur->next = NULL;
					top_table[cur->number]->next = cur;
					cur->prev = top_table[cur->number];
					
					where[cur->number] = cur->number;
					top_table[cur->number] = cur;
					
					cur = tmp;
				}
				
				cur = top_table[where[input[1]]];
				while (cur != location[input[1]])
				{	
					Book* tmp = cur->prev;
					tmp->next = cur->next;
					
					cur->next = NULL;
					top_table[cur->number]->next = cur;
					cur->prev = top_table[cur->number];
					
					where[cur->number] = cur->number;
					top_table[cur->number] = cur;
					
					cur = tmp;
				}
				
				location[input[0]]->prev->next = NULL;
				top_table[where[input[0]]] = location[input[0]]->prev;
				location[input[1]]->next = location[input[0]];
				location[input[0]]->prev = location[input[1]];
				
				where[input[0]] = where[input[1]];
				
				top_table[where[input[1]]] = location[input[0]];
			}
			else	// move over.
			{
				Book* cur = top_table[where[input[0]]];
				while (cur != location[input[0]])
				{	
					Book* tmp = cur->prev;
					tmp->next = cur->next;
					
					cur->next = NULL;
					top_table[cur->number]->next = cur;
					cur->prev = top_table[cur->number];
					
					where[cur->number] = cur->number;
					top_table[cur->number] = cur;
					
					cur = tmp;
				}
				
				location[input[0]]->prev->next = NULL;
				top_table[where[input[0]]] = location[input[0]]->prev;
				top_table[where[input[1]]]->next = location[input[0]];
				location[input[0]]->prev = top_table[where[input[1]]];
				
				where[input[0]] = where[input[1]];
				
				top_table[where[input[1]]] = location[input[0]];
			}
		}
		else
		{
			if (!strcmp(command[1], "onto"))		// pile onto
			{
				Book* cur = top_table[where[input[1]]];
				while (cur != location[input[1]])
				{	
					Book* tmp = cur->prev;
					tmp->next = cur->next;
					
					cur->next = NULL;
					top_table[cur->number]->next = cur;
					cur->prev = top_table[cur->number];
					
					where[cur->number] = cur->number;
					top_table[cur->number] = cur;
					
					cur = tmp;
				}
				
				Book* topA = top_table[where[input[0]]];
				
				location[input[0]]->prev->next = NULL;
				top_table[where[input[0]]] = location[input[0]]->prev;
				location[input[1]]->next = location[input[0]];
				location[input[0]]->prev = location[input[1]];
				
				Book* t = location[input[0]];
				while (t != topA)
				{
					where[t->number] = where[input[1]];
					t = t->next;
				}
				where[t->number] = where[input[1]];
				
				top_table[where[input[1]]] = topA;
			}
			else	// pile over.
			{
				Book* topA = top_table[where[input[0]]];
				
				location[input[0]]->prev->next = NULL;
				top_table[where[input[0]]] = location[input[0]]->prev;
				top_table[where[input[1]]]->next = location[input[0]];
				location[input[0]]->prev = top_table[where[input[1]]];
				
				Book* t = location[input[0]];
				while (t != topA)
				{
					where[t->number] = where[input[1]];
					t = t->next;
				}
				where[t->number] = where[input[1]];
				
				top_table[where[input[1]]] = topA;
			}
		}
		
		/*
		cout << "where" << endl;
		for (int i = 0; i < n; i++)
			cout << i << ' ';
		cout << endl;
		for (int i = 0; i < n; i++)
			cout << where[i] << ' ';
		cout << endl;
		
		cout << "last" << endl;
		for (int i = 0; i < n; i++)
			cout << top_table[i]->number << ' ';
		cout << endl;
		
		for (int i = 0; i < n; i++)
		{
			cout << i << ":";
			
			Book* tmp = table[i];
			while (tmp->next != NULL)
			{
				cout << ' ' << tmp->next->number;
				tmp = tmp->next;
			}
			
			cout << "   ";
			tmp = top_table[i];
			while (tmp->prev != NULL)
			{
				cout << ' ' << tmp->number;
				tmp = tmp->prev;
			}
			cout << tmp->number;
			
			cout << endl;
		}
		*/
		
	}
	
	for (int i = 0; i < n; i++)
	{
		cout << i << ":";
		
		Book* tmp = table[i];
		while (tmp->next != NULL)
		{
			cout << ' ' << tmp->next->number;
			tmp = tmp->next;
		}
		
		cout << endl;
	}
}