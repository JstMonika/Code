#include <bits/stdc++.h>
using namespace std;

int main()
{
	int n, m;
	cin >> n >> m;
	
	int front = 1;
	vector<int> next(n+1);
	vector<int> prev(n+1);
	
	for (int i = 1; i <= n; i++)
	{
		next[i] = i+1;
		prev[i] = i-1;
	}
	
	next[n] = -1;
	prev[1] = -1;
	
	vector<int> q(m);
	map<int, int> c;
	for (int i = 0; i < m; i++)
	{
		cin >> q[i];
		if (c.find(q[i]) == c.end())
			c[q[i]] = 1;
		else
			c[q[i]]++;
	}
	
	for (int i = 0; i < m; i++)
	{
		if (!(--c[q[i]]))
		{
		int tmp = q[i];
		
		if (tmp != front)
		{
			next[prev[tmp]] = next[tmp];
			
			if (next[tmp] != -1)
				prev[next[tmp]] = prev[tmp];
		
			prev[front] = tmp;
			next[tmp] = front;
			prev[tmp] = -1;
			
			front = tmp;
		}
		
		}
	}
	
	while (front != -1)
	{
		cout << front << endl;
		
		front = next[front];
	}
}