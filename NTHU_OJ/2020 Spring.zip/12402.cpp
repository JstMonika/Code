#include <bits/stdc++.h>
using namespace std;

int main()
{
	int T;
	cin >> T;
	
	while (T--)
	{
		double a, b, tmp;
		cin >> a >> b;
		
		tmp = round((b-a) / a * 10000) / 100.0;
		
		cout.width(7);
		cout << fixed << setprecision(2);
		if (tmp >= 5)
			cout << tmp << "% (#`Д´)ﾉ\n";
		else if (tmp <= -5)
			cout << tmp << "% (ゝ∀･)b\n";
		else if (tmp == 0)
			cout << "   0.00% \\^o^/\n";
		else
			cout << tmp << "% \\^o^/\n";
	}
}